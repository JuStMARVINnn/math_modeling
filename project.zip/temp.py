import tkinter as tk

SCREEN_WEIGHT = 800
SCREEN_HEIGHT = 600

window = tk.Tk()
canvas = tk.Canvas(width=SCREEN_WEIGHT, height=SCREEN_HEIGHT, bg="green")
circle = canvas.create_oval(300, 300, 300, 40,
                            fill="red")
canvas.after_idle(move)
#button = tk.Button(master=window, text="Press me!", command=move)

canvas.pack()
#button.pack()
window.mainloop()
move()

def move():
    x = 10
    y = 10
    canvas.move(circle, x, y)
    window.after(1000, move)
